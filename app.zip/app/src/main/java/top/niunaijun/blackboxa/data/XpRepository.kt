package top.niunaijun.blackboxa.data

import android.net.Uri
import android.util.Log
import android.webkit.URLUtil
import androidx.lifecycle.MutableLiveData
import java.io.File
import top.niunaijun.blackbox.BlackBoxCore
import top.niunaijun.blackboxa.R
import top.niunaijun.blackboxa.bean.XpModuleInfo
import top.niunaijun.blackboxa.util.getString

class XpRepository {
    val TAG: String = "XpRepository"

    fun getXpModuleList(modulesLiveData: MutableLiveData<List<XpModuleInfo>>) {
        try {
            val list = mutableListOf<XpModuleInfo>()
            BlackBoxCore.get().installedXPModules.forEach { module ->
                try {
                    val icon =
                            try {
                                module.application?.loadIcon(BlackBoxCore.getPackageManager())
                            } catch (e: Exception) {
                                null
                            }
                    list.add(
                            XpModuleInfo(
                                    module.name ?: module.packageName,
                                    module.desc ?: "",
                                    module.packageName,
                                    module.main ?: "",
                                    module.enable,
                                    icon
                            )
                    )
                } catch (e: Exception) {
                    Log.e(TAG, "Error mapping module ${module.packageName}: ${e.message}")
                }
            }
            modulesLiveData.postValue(list)
        } catch (e: Exception) {
            Log.e(TAG, "Error in getXpModuleList: ${e.message}")
            modulesLiveData.postValue(emptyList())
        }
    }

    fun installModule(source: String, resultLiveData: MutableLiveData<String>) {
        try {
            val blackBoxCore = BlackBoxCore.get()
            val installResult =
                    if (URLUtil.isValidUrl(source)) {
                        blackBoxCore.installXPModule(Uri.parse(source))
                    } else {
                        val file = File(source)
                        if (file.exists()) {
                            blackBoxCore.installXPModule(file)
                        } else {
                            blackBoxCore.installXPModule(source)
                        }
                    }
            if (installResult.success) {
                resultLiveData.postValue(getString(R.string.install_success))
            } else {
                resultLiveData.postValue(getString(R.string.install_fail, installResult.msg))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error installing XP module: ${e.message}")
            resultLiveData.postValue("Installation failed: ${e.message}")
        }
    }

    fun unInstallModule(packageName: String, resultLiveData: MutableLiveData<String>) {
        try {
            BlackBoxCore.get().uninstallXPModule(packageName)
            resultLiveData.postValue(getString(R.string.uninstall_success))
        } catch (e: Exception) {
            Log.e(TAG, "Error uninstalling XP module: ${e.message}")
            resultLiveData.postValue("Uninstallation failed: ${e.message}")
        }
    }
}
